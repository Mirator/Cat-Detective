public enum Location
{
    Garden,
    Bakery,
    Barn,
    Treehouse,
    Beach,
    Store
}
