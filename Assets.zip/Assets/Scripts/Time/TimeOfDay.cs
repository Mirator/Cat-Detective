public enum TimeOfDay
{
    Morning,
    Noon,
    Evening
}
